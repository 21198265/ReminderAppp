package com.example.reminderapp;

public class Class_Task {
    String _class;
    // choiru's comment
    // will comment
    public Class_Task() {}

    public Class_Task(String Class){
        this._class = Class;
    }

    void set_class(String Class){
        this._class = Class;
    }
    public String getclassname(){
        return this._class;
    }
}
