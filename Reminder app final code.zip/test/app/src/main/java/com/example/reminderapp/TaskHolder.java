package com.example.reminderapp;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TaskHolder extends RecyclerView.ViewHolder {
    // class made to store tasks loaded into recycler view

    public TaskHolder(@NonNull View itemView) {
        super(itemView);
    }
}
